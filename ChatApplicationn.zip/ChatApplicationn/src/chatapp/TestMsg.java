package chatapp;




import java.util.Scanner;

public class TestMsg {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        chatService service = new chatService();

        System.out.print("Enter your name: ");
        String name = sc.next();

        System.out.print("Enter message: ");
        sc.nextLine();
        String text = sc.nextLine();

        messageDTO msg = new messageDTO();
        msg.setSender(name);
        msg.setMessage(text);

        service.send(msg);

        System.out.println("\n--- Chat Messages ---");
        service.view();
    }
}

