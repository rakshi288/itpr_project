package chatapp;

	public interface messageDAO {
	    void sendMessage(messageDTO msg);
	    void viewMessages();
	}



