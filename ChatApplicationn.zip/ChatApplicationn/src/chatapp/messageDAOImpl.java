package chatapp;


import java.sql.*;

public class messageDAOImpl implements messageDAO {

    public void sendMessage(messageDTO msg) {
        try {
            Connection con = DBUtil.getConnection();
            PreparedStatement ps =
                con.prepareStatement("INSERT INTO messages(sender,message) VALUES(?,?)");
            ps.setString(1, msg.getSender());
            ps.setString(2, msg.getMessage());
            ps.executeUpdate();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void viewMessages() {
        try {
            Connection con = DBUtil.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM messages");

            while (rs.next()) {
                System.out.println(rs.getString("sender") + " : " +
                                   rs.getString("message"));
            }
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
