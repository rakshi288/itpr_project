package chatapp;





public class chatService {
    messageDAO dao = new messageDAOImpl();

    public void send(messageDTO msg) {
        dao.sendMessage(msg);
    }

    public void view() {
        dao.viewMessages();
    }
}

